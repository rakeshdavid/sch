<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StripeConnection extends Model
{
    protected $table = 'stripe_connections';
}
