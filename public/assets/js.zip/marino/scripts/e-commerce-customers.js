/**
 * @author Batch Themes Ltd.
 */
(function() {
    'use strict';

    $(function() {

        var config = $.localStorage.get('config');
        $('body').attr('data-layout', config.layout);
         $('body').attr('data-palette', config.theme);  $('body').attr('data-direction', config.direction);

        var colors = config.colors;
        var palette = config.palette;

        worldMap('customers-vector-map', colors, palette);
    });

})();
