<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LogType extends Model
{
    protected $table = 'logs_types';

    public $timestamps = false;

}
